import { redirect } from "next/navigation";

export default function StartFreeTrialPage() {
  redirect("https://app.xplorebyte.com/signup-for-trial");
}
