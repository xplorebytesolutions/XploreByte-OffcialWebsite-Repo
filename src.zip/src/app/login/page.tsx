import { redirect } from "next/navigation";

export default function LoginPage() {
  redirect("https://app.xplorebyte.com/login");
}
